module.exports = {
	secret: "diariko-secret-key"
};